"""Verify the public archive without running RELAP5 or fitting an optimizer."""
from __future__ import annotations
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def public_path(parent, value):
    path = (parent / value).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError("Reference escapes the public package")
    if not path.is_file():
        raise FileNotFoundError(path.relative_to(ROOT))
    return path


def development_metrics(path):
    rows = read_csv(path)
    end = max(float(row["time_s"]) for row in rows)
    start = end - 300.0
    rows = [row for row in rows if start - 1e-8 <= float(row["time_s"]) <= end + 1e-8]
    times = [float(row["time_s"]) for row in rows]
    errors = [3000000.0 - float(row["sg_pressure_Pa"]) for row in rows]
    commands = [float(row["feedwater_command_kg_s"]) for row in rows]
    intervals = [b - a for a, b in zip(times, times[1:])]
    if not all(dt > 0 for dt in intervals):
        raise ValueError("Non-increasing development timestamps")
    iae = sum(0.5 * (abs(a) + abs(b)) * dt for a, b, dt in zip(errors, errors[1:], intervals))
    movements = [abs(b - a) for a, b in zip(commands, commands[1:])]
    last_violations = [i for i, error in enumerate(errors) if abs(error) > 3000.0]
    last = max(last_violations, default=-1)
    settling = times[last + 1] - start if last < len(times) - 1 else math.nan
    tail = [error for time, error in zip(times, errors) if time >= end - 50.0 - 1e-8]
    return {
        "IAE (Pa s)": iae,
        "Peak pressure deviation (Pa)": max(map(abs, errors)),
        "Settling time (s)": settling,
        "Terminal |SSE| (Pa)": abs(sum(tail) / len(tail)),
        "TVfw (kg/s)": sum(movements),
        "Maximum feedwater adjustment rate (kg/s2)": max(move / dt for move, dt in zip(movements, intervals)),
    }


def main():
    inventory = read_csv(ROOT / "docs/data_inventory.csv")
    checked = 0
    reference_count = 0
    for entry in inventory:
        path = public_path(ROOT, entry["file"])
        if digest(path) != entry["sha256"].lower():
            raise ValueError("Inventory hash mismatch: " + entry["file"])
        checked += 1
        if path.suffix.lower() == ".csv":
            rows = read_csv(path)
            if len(rows) != int(entry["rows"]):
                raise ValueError("Row count mismatch: " + entry["file"])
            for row in rows:
                for key, hash_key in [("trajectory_path", "trajectory_sha256"), ("source_timeseries", "source_timeseries_sha256")]:
                    if row.get(key):
                        trajectory = public_path(path.parent, row[key])
                        if row.get(hash_key) and digest(trajectory) != row[hash_key].lower():
                            raise ValueError("Trajectory hash mismatch: " + entry["file"])
                        reference_count += 1
    formal = read_csv(ROOT / "data/metrics/formal_evaluations.csv")
    pareto = read_csv(ROOT / "data/metrics/pareto_front.csv")
    independent = read_csv(ROOT / "data/metrics/independent_assessments.csv")
    feasible = [row for row in formal if row["feasibility"].lower() == "true"]
    stages = Counter(row["stage"] for row in formal)
    assert len(formal) == 60 and len(feasible) == 55 and len(pareto) == 48
    assert sum(count for stage, count in stages.items() if stage.startswith("lhs")) == 30
    assert sum(count for stage, count in stages.items() if not stage.startswith("lhs")) == 30
    selected = min(pareto, key=lambda row: float(row["utopia_distance_D"]))
    assert selected["evaluation_id"] == "LHS-MOBO-003"
    assert math.isclose(float(selected["Kp"]), 17.774217370678, rel_tol=1e-12)
    assert math.isclose(float(selected["Ki"]), 0.0003748218881211, rel_tol=1e-12)
    cases = defaultdict(list)
    for row in independent:
        cases[row["case_id"]].append(row["controller_role"])
    assert len(independent) == 20 and len(cases) == 10
    assert all(len(roles) == 2 and len(set(roles)) == 2 for roles in cases.values())
    expected = {row["metric"]: row for row in read_csv(ROOT / "data/figure_sources/Table4_development_performance.csv")}
    recomputed = {}
    for role, filename in [("baseline", "BASELINE-MOBO-V1_timeseries.csv"), ("selected", "LHS-MOBO-003_timeseries.csv")]:
        values = development_metrics(ROOT / "data/trajectories/development" / filename)
        for metric, value in values.items():
            if not math.isclose(value, float(expected[metric][role]), rel_tol=1e-8, abs_tol=1e-5):
                raise ValueError(f"Development metric mismatch: {role}, {metric}: {value}")
        recomputed[role] = values
    qualification = json.loads((ROOT / "data/numerical_checks/qualification_decision.json").read_text(encoding="utf-8"))
    assert qualification["passed"] is False
    assert qualification["objective_relative_changes"]["F_R"] > qualification["study_specific_objective_relative_tolerance"]
    print(json.dumps({
        "archive_integrity": "pass",
        "data_files_checked": checked,
        "trajectory_references_checked": reference_count,
        "formal_evaluations": len(formal),
        "recorded_feasible": len(feasible),
        "recorded_pareto": len(pareto),
        "independent_cases": len(cases),
        "development_metrics_recomputed": recomputed,
        "original_numerical_qualification_passed": qualification["passed"],
        "qualification_relative_changes": qualification["objective_relative_changes"],
        "scope": "Checks archived public records; does not rerun simulations or establish numerical qualification."
    }, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
