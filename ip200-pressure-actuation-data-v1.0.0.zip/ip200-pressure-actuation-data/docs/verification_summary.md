# Archive verification

The standard-library verification utility completed successfully on the prepared package. It checked 101 data-file inventory hashes and 586 internal trajectory references, confirmed 60 formal evaluations, 55 recorded feasible observations, 48 recorded Pareto observations and ten paired independent cases.

The following development-response values were recomputed from the public trajectory columns and matched the archived Table 4 source values within the utility's stated floating-point tolerance.

| Metric | Baseline | Selected |
|---|---:|---:|
| IAE (Pa s) | 13870825.5 | 4665734.5 |
| Peak pressure deviation (Pa) | 278250 | 104440 |
| Settling time (s) | 161.0 | 132.5 |
| Absolute mean signed error in final 50 s (Pa) | 1563.253493013972 | 468.72255489021956 |
| Feedwater-command total variation (kg/s) | 25.738 | 26.585000000000065 |
| Maximum sampled command rate (kg/s2) | 0.570000000000216 | 1.1099999999997896 |

No RELAP5 simulation or optimizer was run for this verification. Other archived metrics and classifications are retained as recorded. This integrity check does not establish scientific validity or numerical convergence. In particular, the original fine-timestep qualification remains `passed: false` because the recorded F_R change exceeds the original 5% criterion.
