# Data dictionary

This is a local repository draft. Data values are archived observations, not new simulations. The accompanying inventory lists every packaged data file and its SHA-256 fingerprint. Blank or non-finite values, failed responses and non-settling cases are retained as recorded. Approval for public release is pending.

## Dataset families

| Directory/file | Content |
|---|---|

## Definitions requiring particular care

- The selected observation is `LHS-MOBO-003`, Kp = 17.774217370678 and Ki = 0.0003748218881211. Selection does not imply the sequential stage discovered this observation.
- Historical `terminal_abs_SSE` is the absolute mean of signed pressure error over the final 50 s, including boundary samples. It is neither endpoint error nor the mean absolute error. Some historical figure/table row labels still say terminal SSE; their original strings and numbers are preserved here.
- Historical `c_A` uses the broad computational command interval 0–1000 kg/s. The later 0–100 kg/s check is a separate post-hoc archived-sample check. Neither is documented as a validated hardware limit.
- The existing 0.005-to-0.0025-s maximum-timestep check failed its original 5% objective-change tolerance: F_R changed by about 14.4144%. Its JSON retains `passed: false`. Both trajectories were archived at approximately 0.1 s intervals; integration timestep and archive interval are different quantities.
- Ordinary formal and independent response metrics use a 300 s evaluation window after ramp initiation. The unloading/reloading sequence uses its recorded 620 s window. Raw trajectory files also retain guard samples; use the explicit assessment-window fields when available.
- The original datasets retain development-baseline normalizers for formal objectives. Independent-case ratios use each matching case baseline; a pressure composite can be blank when that baseline does not settle. Numerical-check ratios retain the formal baseline denominators.
- Public development, independent-assessment and QUAL trajectories contain only `time_s`, `sg_pressure_Pa`, `feedwater_command_kg_s`, `steam_mass_flow_kg_s` and `feedwater_mass_flow_kg_s`, which support pressure performance, feedwater-command activity analysis and the archived command/actual-flow post-check. Fourteen unrelated thermal/power/primary-side/boundary-flow/control-component fields were omitted; all retained numerical strings, sample times and adverse trajectories remain unchanged. Figure/table source CSV contents retain their original study values.
- Input/output/log path columns referring to excluded restricted files were removed. Included trajectory references are relative to their CSV. `trajectory_sha256` and `source_timeseries_sha256` now fingerprint the included five-field public files. `original_trajectory_sha256` and `original_source_timeseries_sha256` preserve the corresponding private original-archive fingerprints. The original fingerprints must not be mistaken for public-file fingerprints. Hashes of excluded artifacts are fingerprints, not included file contents.

## Recorded fields

Units marked `not recorded` are intentionally not inferred. For row-wise heterogeneous metric tables, use their metric/unit labels. A field can have different roles in different historical files; dataset context is retained.

| Field | Units | Definition / handling |
|---|---|---|
| `F_P` | dimensionless | Historical normalized weighted pressure index; includes final-50-s mean error term. |
| `F_P_defined` | not applicable | Archived boolean indicating whether the pressure objective was defined. |
| `F_P_val` | dimensionless | Archived normalized objective, selection coordinate or hypervolume quantity; exact meaning follows field name. |
| `F_R` | dimensionless | Maximum sampled command rate divided by development-baseline sampled rate. |
| `F_R_val` | dimensionless | Archived normalized objective, selection coordinate or hypervolume quantity; exact meaning follows field name. |
| `F_TV` | dimensionless | Command total variation divided by development-baseline total variation. |
| `F_TV_val` | dimensionless | Archived normalized objective, selection coordinate or hypervolume quantity; exact meaning follows field name. |
| `GP_training_row_count` | count / index | Archived count or index identified by field name. |
| `GP_training_stages` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `IAE` | Pa s | Integral absolute pressure error over the recorded evaluation window. |
| `IAE_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `Ki` | kg/s/MPa/s | Integral gain; time is in seconds and error in MPa. |
| `Ki_readback` | kg/s/MPa/s | Archived readback of integral gain. |
| `Kp` | kg/s/MPa | Proportional gain; archived pressure error is in MPa. |
| `Kp_readback` | kg/s/MPa | Archived readback of proportional gain. |
| `RELAP5_status` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `RELAP5_success` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `R_HV_5` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `TV_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `TVfw` | kg/s | Sum of absolute adjacent-sample feedwater-command changes. |
| `TVfw_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `above_100_count` | count / index | Archived count or index identified by field name. |
| `absolute_change` | see units column | Retained archived difference; not recalculated during packaging. |
| `acquisition_value` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `actuator_screen` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `archive_dt_max` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `archive_dt_max_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `archive_dt_median` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `archive_dt_min` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `archive_dt_min_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `archive_end_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `archive_start_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `baseline` | see metric row | Original baseline value; do not mix units between metric rows. |
| `baseline_F_P_val` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `baseline_F_R_val` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `baseline_F_TV_val` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `baseline_IAE` | Pa s | Baseline Integral absolute pressure error over the recorded evaluation window. |
| `baseline_TV_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `baseline_TVfw` | kg/s | Baseline Sum of absolute adjacent-sample feedwater-command changes. |
| `baseline_cycle_dwell_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `baseline_cycle_up_ramp_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `baseline_dynamic_status` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `baseline_evaluation_horizon_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `baseline_initial_load_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `baseline_maximum_PSG_Pa` | Pa | Archived pressure or pressure-error quantity identified by field name. |
| `baseline_maximum_abs_pressure_deviation` | Pa | Baseline Maximum absolute common-steam-pressure error. |
| `baseline_maximum_feedwater_rate` | kg/s^2 | Baseline Maximum absolute adjacent-sample command change divided by sample interval. |
| `baseline_minimum_PSG_Pa` | Pa | Archived pressure or pressure-error quantity identified by field name. |
| `baseline_persistent_oscillation_flag` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `baseline_pressure_benefit_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `baseline_ramp_duration_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `baseline_rate_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `baseline_settled` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `baseline_settling_time` | s | Baseline Time from the specified settling origin; blank if undefined/non-settling. |
| `baseline_target_load_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `baseline_terminal_abs_SSE` | Pa | Baseline Historical field: absolute arithmetic mean of signed pressure error over final 50 s; not endpoint error or mean absolute error. |
| `below_0_count` | count / index | Archived count or index identified by field name. |
| `c_A` | kg/s | Historical command residual max(-minimum command, maximum command minus 1000); feasible when <= 0. |
| `c_P` | MPa | Historical pressure-constraint residual; feasible when <= 0. |
| `c_s` | s | Historical settling-time residual relative to 300 s; feasible when <= 0. |
| `campaign` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `case_id` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `cleaning_rule` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `cohort` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `condition` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `controller` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `controller_role` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `cycle_dwell_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `cycle_up_ramp_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `display_label` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `down_ramp_end_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `duplicate_timestamp_count` | count / index | Archived count or index identified by field name. |
| `dynamic_flag` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `dynamic_status` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `evaluation_end_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `evaluation_horizon_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `evaluation_id` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `evaluation_start_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `evidence_tier` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `existing_0p0025` | see units column | Archived check result with maximum integration timestep 0.0025 s. |
| `existing_check_run_id` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `failure_reason` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `feasibility` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `feedwater_command_kg_s` | kg/s | Controller command used by actuation objectives; distinct from realized boundary-flow signal. |
| `final_steam_flow_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `finite_sample_count` | count / index | Archived count or index identified by field name. |
| `formal_0p005` | see units column | Archived formal result with maximum integration timestep 0.005 s. |
| `formal_order` | count / index | Archived count or index identified by field name. |
| `formal_run_id` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `gross_actuator_sanity` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `historical_formal_command_threshold_kg_s` | kg/s | Recorded historical broad command condition; 0–1000, distinct from later 0–100 post-check. |
| `hypervolume` | dimensionless | Archived normalized objective, selection coordinate or hypervolume quantity; exact meaning follows field name. |
| `initial_load_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `initial_steam_flow_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `input_hash` | not applicable | Retained source fingerprint only; restricted source file content is excluded. |
| `interpretation` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `iteration_wall_time_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `label_EN` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `label_ZH` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `log10Ki` | dimensionless | Archived base-10 log transform of integral gain for search. |
| `max_feedwater_rate` | kg/s^2 | Maximum absolute adjacent-sample command change divided by sample interval. |
| `max_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `maximum_PSG_Pa` | Pa | Archived pressure or pressure-error quantity identified by field name. |
| `maximum_abs_pressure_deviation` | Pa | Maximum absolute common-steam-pressure error. |
| `maximum_abs_pressure_deviation_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `maximum_feedwater_command_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `maximum_feedwater_rate` | kg/s^2 | Maximum absolute adjacent-sample command change divided by sample interval. |
| `maximum_feedwater_rate_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `metric` | see row label | Metric name; units appear in its row label. |
| `min_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `minimum_PSG_Pa` | Pa | Archived pressure or pressure-error quantity identified by field name. |
| `minimum_distance_to_existing` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `minimum_feedwater_command_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `missing_nonfinite_signal_count` | count / index | Archived count or index identified by field name. |
| `mobo_iteration` | count / index | Archived count or index identified by field name. |
| `nonincreasing_timestamp_intervals` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `objective_extreme` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `old_J` | dimensionless | Retained historical objective; not the three-objective compromise selection criterion. |
| `oscillation_flag` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `output_hash` | not applicable | Retained source fingerprint only; restricted source file content is excluded. |
| `outside_0_100_count` | count / index | Archived count or index identified by field name. |
| `outside_timestamps_abs_s_json` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `outside_timestamps_from_evaluation_start_s_json` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `pareto` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `pareto_rank` | count / index | Archived count or index identified by field name. |
| `peak_pressure_deviation` | Pa | Maximum absolute common-steam-pressure error. |
| `persistent_oscillation_flag` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `phase` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `postcheck_lower_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `postcheck_upper_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `predicted_constraints` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `predicted_feasibility_probability` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `pressure_benefit_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `pressure_screen` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `ramp_duration_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `ramp_end_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `rate_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `relap_identifier` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `relative_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `relative_change_percent` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `relative_time_s` | s | Archived figure display time; do not assume it is absolute simulation time. |
| `reload_end_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `reload_start_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `requested_max_timestep_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `restart_hash` | not applicable | Retained source fingerprint only; restricted source file content is excluded. |
| `restart_record_present` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `run_id` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `runtime_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `sample_count` | count / index | Archived count or index identified by field name. |
| `selected` | see metric row / not applicable | Original selected value or selection flag, depending on file; see dataset family. |
| `selected_F_P_val` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `selected_F_R_val` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `selected_F_TV_val` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `selected_IAE` | Pa s | Selected Integral absolute pressure error over the recorded evaluation window. |
| `selected_TV_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `selected_TVfw` | kg/s | Selected Sum of absolute adjacent-sample feedwater-command changes. |
| `selected_cycle_dwell_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `selected_cycle_up_ramp_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `selected_dynamic_status` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `selected_evaluation_horizon_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `selected_initial_load_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `selected_maximum_PSG_Pa` | Pa | Archived pressure or pressure-error quantity identified by field name. |
| `selected_maximum_abs_pressure_deviation` | Pa | Selected Maximum absolute common-steam-pressure error. |
| `selected_maximum_feedwater_rate` | kg/s^2 | Selected Maximum absolute adjacent-sample command change divided by sample interval. |
| `selected_minimum_PSG_Pa` | Pa | Archived pressure or pressure-error quantity identified by field name. |
| `selected_persistent_oscillation_flag` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `selected_pressure_benefit_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `selected_ramp_duration_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `selected_rate_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `selected_settled` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `selected_settling_time` | s | Selected Time from the specified settling origin; blank if undefined/non-settling. |
| `selected_target_load_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `selected_terminal_abs_SSE` | Pa | Selected Historical field: absolute arithmetic mean of signed pressure error over final 50 s; not endpoint error or mean absolute error. |
| `settled` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `settling_censored_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `settling_origin_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `settling_time` | s | Time from the specified settling origin; blank if undefined/non-settling. |
| `settling_time_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `sg_pressure_Pa` | Pa | Archived pressure or pressure-error quantity identified by field name. |
| `signal` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `signal_role` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `source` | not applicable | Archived row role or provenance label; no source file contents are included. |
| `source_master_sha256` | not applicable | Retained source fingerprint only; restricted source file content is excluded. |
| `source_missing_nonfinite_time_count` | count / index | Archived count or index identified by field name. |
| `source_timeseries` | not applicable | Relative path from this CSV to its included trajectory file. |
| `source_timeseries_sha256` | not applicable | SHA-256 of the included public trajectory at the relative reference path. |
| `stage` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `steam_mass_flow_kg_s` | kg/s | Archived mass-flow, command or interval-bound value identified by field name. |
| `target_load_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `technical_status` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `technical_success` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `terminal_SSE_signed` | Pa | Historical signed final-50-s pressure-error mean; sign convention is PSG minus set point. |
| `terminal_abs_SSE` | Pa | Historical field: absolute arithmetic mean of signed pressure error over final 50 s; not endpoint error or mean absolute error. |
| `terminal_abs_SSE_change_pct` | % | Archived percentage; comparison basis depends on metric/file, and no packaging recomputation was performed. |
| `time_s` | s | Absolute archived RELAP5 simulation time; guard samples are retained. |
| `timestamp_utc` | not recorded | No additional unit/definition is asserted; consult the original field name and accompanying source row labels. |
| `trajectory_path` | not applicable | Relative path from this CSV to its included trajectory file. |
| `trajectory_sha256` | not applicable | SHA-256 of the included public trajectory at the relative reference path. |
| `transfer_classification` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `units` | not applicable | Row-specific unit recorded by the archived source. |
| `utopia_distance_D` | dimensionless | Archived normalized objective, selection coordinate or hypervolume quantity; exact meaning follows field name. |
| `window` | not applicable | Archived identifier, status or explanatory label; retained verbatim. |
| `window_end_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `window_end_sample_present` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `window_start_abs_s` | s | Archived time, time interval, timing constraint or duration identified by field name. |
| `window_start_sample_present` | not applicable | Archived status/boolean or classification; false/blank values are retained. |
| `x1` | dimensionless | Archived transformed decision coordinate. |
| `x2` | dimensionless | Archived transformed decision coordinate. |
| `z_P` | dimensionless | Archived normalized objective, selection coordinate or hypervolume quantity; exact meaning follows field name. |
| `z_R` | dimensionless | Archived normalized objective, selection coordinate or hypervolume quantity; exact meaning follows field name. |
| `z_TV` | dimensionless | Archived normalized objective, selection coordinate or hypervolume quantity; exact meaning follows field name. |

| `original_trajectory_sha256` | not applicable | SHA-256 of the private original trajectory before public five-field projection; original file is not included. |
| `original_source_timeseries_sha256` | not applicable | SHA-256 of the private original timeseries before public five-field projection; original file is not included. |

| `feedwater_mass_flow_kg_s` | kg/s | Archived realized common feedwater-boundary flow; retained to support the command/actual-flow post-check. |

## Numerical-decision JSON

`passed` is the existing overall qualification decision. `study_specific_objective_relative_tolerance` is a dimensionless fraction. `objective_relative_changes` are dimensionless fractions for F_P, F_TV and F_R. Classification-match fields and oscillation flags are recorded diagnostics and do not establish continuous-time stability, timestep independence or hardware feasibility. `failure_policy` records the historical protocol treatment and is retained verbatim.
